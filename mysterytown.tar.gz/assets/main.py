import pygame
import sys
import random
import json
import asyncio
from pathlib import Path
from entities import Player, NPC, Clue

# Konstanten
WIDTH, HEIGHT = 1024, 768
WORLD_WIDTH, WORLD_HEIGHT = WIDTH * 3, HEIGHT * 3
FPS = 60

class Camera:
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        return entity.rect.move(self.camera.topleft)

    def apply_rect(self, rect):
        return rect.move(self.camera.topleft)

    def update(self, target):
        x = -target.rect.centerx + int(WIDTH / 2)
        y = -target.rect.centery + int(HEIGHT / 2)

        # Begrenzung der Kamera auf die Weltgröße
        x = min(0, x)  # Links
        y = min(0, y)  # Oben
        x = max(-(WORLD_WIDTH - WIDTH), x)  # Rechts
        y = max(-(WORLD_HEIGHT - HEIGHT), y)  # Unten
        self.camera = pygame.Rect(x, y, self.width, self.height)

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("MysteryTown - Ermittlung")
        self.clock = pygame.time.Clock()
        # Standard-Font nutzen, da Arial im Browser nicht garantiert ist
        self.font = pygame.font.Font(None, 28)
        
        self.player = Player(WORLD_WIDTH // 2, 300) # Start im Norden
        self.camera = Camera(WORLD_WIDTH, WORLD_HEIGHT)
        
        self.state = "INTRO"  # INTRO, EXPLORING, DIALOGUE, DECISION, ENDING, CODE_ENTRY, INTERIOR
        self.interactions_count = 0
        self.selected_suspect = None
        self.inventory = [] # Liste von Strings (Titel)
        self.inventory_full_data = [] # Liste von Dicts (ganze Daten)
        self.show_inventory = False
        self.inventory_index = 0
        self.has_boat_access = False
        self.input_text = ""
        self.target_house = None
        self.house_codes = {
            "Stadtarchiv": "1234",
            "Haus von Wache Ulrich": "5678",
            "Lottes Laden": "2468",
            "Bäckerei": "1357",
            "Schatzkammer": "OFFEN",
            "Wohnhaus 1": "OFFEN",
            "Wohnhaus 2": "OFFEN"
        }
        self.unlocked_houses = set()
        self.current_interior = None
        self.last_overworld_pos = None
        self.correct_suspect = "Wache Ulrich"
        self.unlock_target = 4
        self.paths = []
        self.trees = []
        self.gravestones = []
        self.lanterns = []
        
        self.current_npc = None
        self.dialogue_step = 0  # 0: Statement, 1: Detail
        self.dialogue_text = ""
        self.dialogue_name = ""
        
        self.npcs = []
        self.clues = []
        self.walls = []
        self.policeman = None
        self.gravestone_moved = False
        self.gravestone_anim_done = False
        self.gravestone_y_offset = 0
        self.interior_objects = {}
        
        self.load_data()
        self.setup_world()

    def load_data(self):
        print("Lade Spieldaten...")
        self.char_data = []
        self.clue_data = []
        
        # Versuche verschiedene Pfade (für maximale Sicherheit im Web)
        possible_paths = ["data/", "./data/", "", "./"]
        
        # Charaktere laden
        loaded_chars = False
        for p in possible_paths:
            try:
                path = f"{p}characters.json"
                with open(path, encoding="utf-8") as f:
                    self.char_data = json.load(f)
                print(f"Erfolg: characters.json geladen von {path}")
                loaded_chars = True
                break
            except Exception as e:
                continue
        
        if not loaded_chars:
            print("FEHLER: characters.json konnte nirgendwo gefunden werden!")

        # Hinweise laden
        loaded_clues = False
        for p in possible_paths:
            try:
                path = f"{p}clues.json"
                with open(path, encoding="utf-8") as f:
                    self.clue_data = json.load(f)
                print(f"Erfolg: clues.json geladen von {path}")
                loaded_clues = True
                break
            except Exception as e:
                continue
        
        if not loaded_clues:
            print("FEHLER: clues.json konnte nirgendwo gefunden werden!")

    def setup_world(self):
        # Weltgrenzen mit Felsen absichern
        self.walls.append(pygame.Rect(0, 0, WORLD_WIDTH, 40))
        self.walls.append(pygame.Rect(0, WORLD_HEIGHT - 40, WORLD_WIDTH, 40))
        self.walls.append(pygame.Rect(0, 0, 40, WORLD_HEIGHT))
        self.walls.append(pygame.Rect(WORLD_WIDTH - 40, 0, 40, WORLD_HEIGHT))

        # Fluss (Nord/Süd Trennung)
        self.river = pygame.Rect(0, WORLD_HEIGHT // 2 - 40, WORLD_WIDTH, 80)
        self.walls.append(self.river)
        
        # Bootshaus
        self.boathouse = pygame.Rect(WORLD_WIDTH // 2 - 50, WORLD_HEIGHT // 2 - 60, 100, 40)
        self.walls.append(self.boathouse)

        # Häuser
        self.houses = {
            "Stadtarchiv": pygame.Rect(400, 400, 150, 100),
            "Haus von Wache Ulrich": pygame.Rect(WORLD_WIDTH - 600, 400, 150, 100),
            "Lottes Laden": pygame.Rect(400, WORLD_HEIGHT - 600, 150, 100),
            "Bäckerei": pygame.Rect(WORLD_WIDTH - 600, WORLD_HEIGHT - 600, 150, 100),
            "Wohnhaus 1": pygame.Rect(WORLD_WIDTH - 500, 1000, 150, 100),
            "Wohnhaus 2": pygame.Rect(500, WORLD_HEIGHT - 1200, 150, 100)
        }
        
        # Marktplatz und Friedhof (Bereiche) - Marktplatz wieder im Norden
        self.marketplace = pygame.Rect(WORLD_WIDTH // 2 - 200, 800, 400, 300)
        self.cemetery = pygame.Rect(WORLD_WIDTH // 2 - 200, WORLD_HEIGHT - 420, 400, 400)

        # Hauptweg Nord-Süd
        main_path = pygame.Rect(WORLD_WIDTH // 2 - 30, 40, 60, WORLD_HEIGHT - 80)
        self.paths.append(main_path)

        # Laternen am Wegesrand platzieren
        self.lanterns.append(pygame.Rect(main_path.right + 10, 120, 20, 30))
        self.lanterns.append(pygame.Rect(main_path.right + 10, 520, 20, 30))
        self.lanterns.append(pygame.Rect(main_path.right + 10, 760, 20, 30))
        self.lanterns.append(pygame.Rect(self.houses["Stadtarchiv"].right + 10, self.houses["Stadtarchiv"].centery, 20, 30))
        
        # Grabsteine für den Friedhof
        for i in range(10):
            gx = self.cemetery.x + 50 + (i % 3) * 120
            gy = self.cemetery.y + 50 + (i // 3) * 100
            gravestone = pygame.Rect(gx, gy, 40, 60)
            self.gravestones.append(gravestone)
            self.walls.append(gravestone)
        
        if self.gravestones:
            last_row_y = max(g.y for g in self.gravestones)
            bottom_right = max((g for g in self.gravestones if g.y == last_row_y), key=lambda g: g.x)
            self.gravestones.remove(bottom_right)
            if bottom_right in self.walls:
                self.walls.remove(bottom_right)
        for house in self.houses.values():
            self.walls.append(house)

        # Weg zum Friedhof
        cemetery_path_x = min(WORLD_WIDTH // 2, self.cemetery.left)
        cemetery_path_width = abs(self.cemetery.left - WORLD_WIDTH // 2)
        self.paths.append(pygame.Rect(cemetery_path_x, self.cemetery.centery - 20, cemetery_path_width, 40))
        
        # Wege zu den Häusern
        for name, rect in self.houses.items():
            path_y = rect.centery
            if rect.centerx < WORLD_WIDTH // 2:
                self.paths.append(pygame.Rect(rect.right, path_y - 20, WORLD_WIDTH // 2 - rect.right, 40))
            else:
                self.paths.append(pygame.Rect(WORLD_WIDTH // 2, path_y - 20, rect.left - WORLD_WIDTH // 2, 40))

        # Bäume 
        import random
        random.seed(42)
        

        for name, house in self.houses.items():
            for _ in range(5):
                tx = house.x + random.randint(-100, 200)
                ty = house.y + random.randint(-100, 200)
                tree_rect = pygame.Rect(tx, ty, 40, 40)
                
                entrance_area = pygame.Rect(house.centerx - 30, house.bottom, 60, 50)
                if not tree_rect.colliderect(house) and not tree_rect.colliderect(entrance_area) and not tree_rect.colliderect(self.river):
                    self.trees.append(tree_rect)
                    self.walls.append(tree_rect)

        # Bäume um den Friedhof
        for _ in range(15):
            tx = self.cemetery.x + random.randint(-100, 500)
            ty = self.cemetery.y + random.randint(-100, 500)
            tree_rect = pygame.Rect(tx, ty, 40, 40)
            if not tree_rect.colliderect(self.cemetery) and not tree_rect.colliderect(self.river):
                self.trees.append(tree_rect)
                self.walls.append(tree_rect)

        #  zufällige Bäume in der Welt
        for _ in range(50):
            tx = random.randint(100, WORLD_WIDTH - 100)
            ty = random.randint(100, WORLD_HEIGHT - 100)
            tree_rect = pygame.Rect(tx, ty, 40, 40)
            collision = False
            if tree_rect.colliderect(self.river) or tree_rect.colliderect(self.boathouse): collision = True
            for house in self.houses.values():
                if tree_rect.colliderect(house.inflate(40, 40)): collision = True
            for path in self.paths:
                if tree_rect.colliderect(path.inflate(20, 20)): collision = True
            if tree_rect.colliderect(self.marketplace) or tree_rect.colliderect(self.cemetery): collision = True
            if not collision:
                self.trees.append(tree_rect)
                self.walls.append(tree_rect)
        
        # Eingänge (Grüne Kästchen)
        self.entrances = {}
        for name, rect in self.houses.items():
            self.entrances[name] = pygame.Rect(rect.centerx - 10, rect.bottom - 5, 20, 10)

        # NPCs verteilen (Draußen oder Innen)
        for data in self.char_data:
            if data['name'] == "Bibliothekarin Sabine":
                data['interior'] = "Stadtarchiv"
                self.npcs.append(NPC(data['name'], WIDTH // 2 - 60, HEIGHT // 2, data))
            elif data['name'] == "Händlerin Lotte":
                data['interior'] = "Lottes Laden"
                self.npcs.append(NPC(data['name'], WIDTH // 2 + 60, HEIGHT // 2, data))
            elif data['name'] == "Bäckerin Anna":
                data['interior'] = "Bäckerei"
                self.npcs.append(NPC(data['name'], WIDTH // 2, HEIGHT // 2 - 60, data))
            elif data['name'] == "Wache Ulrich":
                self.npcs.append(NPC(data['name'], WORLD_WIDTH // 2 - 250, 900, data))
            elif data['name'] == "Kind Jonas":
                self.npcs.append(NPC(data['name'], WORLD_WIDTH // 2 + 240, 920, data))
            elif data['name'] == "Schmied Thorsten":
                self.npcs.append(NPC(data['name'], 420, WORLD_HEIGHT - 420, data))
            else:
                self.npcs.append(NPC(data['name'], WORLD_WIDTH // 2 + 20, 620, data))
        
        # Polizist am ganz nördlichen Rand der Welt
        self.policeman = NPC("Polizist", WORLD_WIDTH // 2, 100, {
            "statement": "Haben Sie neue Erkenntnisse?", 
            "detail": "Ich nehme Ihren Bericht erst an, wenn Sie alle vier Häuser der Stadt gründlich durchsucht haben."
        })
        self.npcs.append(self.policeman)
            
        
        # 1. Roter Mantel (Marktplatz)
        self.clues.append(Clue(self.clue_data[0]['title'], WORLD_WIDTH // 2 - 100, 900, self.clue_data[0]))
        # 2. Fußspuren (Verschoben nach weiter unten)
        self.clues.append(Clue(self.clue_data[1]['title'], WORLD_WIDTH - 580, WORLD_HEIGHT - 300, self.clue_data[1]))
        # 3. Verkaufte Ware (Jetzt beim Friedhof platziert)
        self.clues.append(Clue(self.clue_data[2]['title'], WORLD_WIDTH // 2 - 250, WORLD_HEIGHT - 350, self.clue_data[2]))
        # 4. Verschlammte Stiefel (Draußen Süd)
        self.clues.append(Clue(self.clue_data[3]['title'], 100, WORLD_HEIGHT - 150, self.clue_data[3]))
        # 5. Zerrissene Karte (Friedhof)
        self.clues.append(Clue(self.clue_data[4]['title'], WORLD_WIDTH - 400, 1700, self.clue_data[4]))
        # 6. Schlüssel (Marktplatz versteckt)
        self.clues.append(Clue(self.clue_data[5]['title'], WORLD_WIDTH // 2 + 150, 850, self.clue_data[5]))
        # 7. Zettel mit Code (Draußen Süd)
        self.clues.append(Clue(self.clue_data[6]['title'], WORLD_WIDTH // 2, WORLD_HEIGHT // 2 + 400, self.clue_data[6]))
        # 8. Historische Dokumente (Stadtarchiv Innen)
        self.clues.append(Clue("Historische Dokumente", WIDTH // 2, HEIGHT // 2 - 100, {"description": "Alte Aufzeichnungen über die Schatzkammer.", "interior": "Stadtarchiv"}))
        # 9. Leeres Podest (Schatzkammer Innen)
        self.clues.append(Clue("Leeres Podest", WIDTH // 2, HEIGHT // 2, {"description": "Hier sollte das Artefakt liegen. Es wurde gewaltsam entfernt. Kohlekrümel und Glassplitter liegen noch auf dem Boden.", "interior": "Schatzkammer"}))
        # 10. Alte Kasse (Lottes Laden) - Index 7
        self.clues.append(Clue(self.clue_data[7]['title'], WIDTH // 2 + 100, HEIGHT // 2 - 50, self.clue_data[7]))
        # 11. Aufgerissener Mehlsack (Bäckerei) - Index 8
        self.clues.append(Clue(self.clue_data[8]['title'], WIDTH // 2 - 100, HEIGHT // 2 - 50, self.clue_data[8]))
        
        # Spezielle Innenraum-Objekte (Möbel und Dekoration)
        self.interior_objects = {
            "Lottes Laden": [
                {"rect": pygame.Rect(WIDTH // 2 - 150, HEIGHT // 2 - 40, 300, 60), "color": (100, 70, 40), "label": "Verkaufstheke"},
                {"rect": pygame.Rect(50, 100, 40, 400), "color": (80, 60, 40), "label": "Regal"},
                {"rect": pygame.Rect(WIDTH - 90, 100, 40, 400), "color": (80, 60, 40), "label": "Regal"}
            ],
            "Bäckerei": [
                {"rect": pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 - 40, 200, 80), "color": (120, 90, 60), "label": "Backtheke"},
                {"rect": pygame.Rect(WIDTH // 2 - 60, 50, 120, 60), "color": (60, 30, 10), "label": "Ofen"},
                {"rect": pygame.Rect(100, 100, 60, 60), "color": (200, 190, 180), "label": "Mehlsack-Stapel"}
            ],
            "Stadtarchiv": [
                {"rect": pygame.Rect(WIDTH // 2 - 150, 100, 300, 40), "color": (70, 50, 30), "label": "Bücherregal"},
                {"rect": pygame.Rect(100, 200, 40, 300), "color": (70, 50, 30), "label": "Bücherregal"},
                {"rect": pygame.Rect(WIDTH - 140, 200, 40, 300), "color": (70, 50, 30), "label": "Bücherregal"}
            ]
        }

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if event.type == pygame.KEYDOWN:
                if self.state == "INTRO":
                    if event.key == pygame.K_e or event.key == pygame.K_SPACE:
                        self.state = "EXPLORING"
                elif self.state == "EXPLORING":
                    if event.key == pygame.K_e or event.key == pygame.K_SPACE:
                        self.interact()
                    if event.key == pygame.K_i:
                        self.show_inventory = not self.show_inventory
                        self.inventory_index = 0
                    if self.show_inventory:
                        if event.key == pygame.K_UP:
                            self.inventory_index = max(0, self.inventory_index - 1)
                        elif event.key == pygame.K_DOWN:
                            self.inventory_index = min(len(self.inventory) - 1, self.inventory_index + 1)
                        elif event.key == pygame.K_RETURN and self.inventory:
                            # Hinweis erneut anzeigen
                            self.state = "DIALOGUE"
                            self.dialogue_name = self.inventory_full_data[self.inventory_index]['title']
                            self.dialogue_text = self.inventory_full_data[self.inventory_index]['description']
                            self.show_inventory = False
                elif self.state == "INTERIOR":
                    if event.key == pygame.K_e or event.key == pygame.K_SPACE:
                        self.interact()
                    if event.key == pygame.K_i:
                        self.show_inventory = not self.show_inventory
                        self.inventory_index = 0
                    if self.show_inventory:
                        if event.key == pygame.K_UP:
                            self.inventory_index = max(0, self.inventory_index - 1)
                        elif event.key == pygame.K_DOWN:
                            self.inventory_index = min(len(self.inventory) - 1, self.inventory_index + 1)
                        elif event.key == pygame.K_RETURN and self.inventory:
                            self.state = "DIALOGUE"
                            self.dialogue_name = self.inventory_full_data[self.inventory_index]['title']
                            self.dialogue_text = self.inventory_full_data[self.inventory_index]['description']
                            self.show_inventory = False
                elif self.state == "DIALOGUE":
                    if event.key == pygame.K_e or event.key == pygame.K_SPACE:
                        # Sicherheitsprüfung: Nur wenn ein NPC aktuell ist, Details anzeigen
                        if self.current_npc and self.dialogue_step == 0:
                            self.dialogue_text = self.current_npc.data.get('detail', "Keine weiteren Details.")
                            self.dialogue_step = 1
                        else:
                            self.interactions_count += 1
                            # Zurück zum vorherigen Zustand (EXPLORING oder INTERIOR)
                            if self.current_interior:
                                self.state = "INTERIOR"
                            else:
                                self.state = "EXPLORING"
                            self.current_npc = None
                            self.dialogue_step = 0
                    elif event.key == pygame.K_ESCAPE:
                        self.current_npc = None
                        self.dialogue_step = 0
                        if self.current_interior:
                            self.state = "INTERIOR"
                        else:
                            self.state = "EXPLORING"
                elif self.state == "CODE_ENTRY":
                    if event.key == pygame.K_RETURN:
                        if self.input_text == self.house_codes.get(self.target_house):
                            self.unlocked_houses.add(self.target_house)
                            self.enter_interior(self.target_house)
                        else:
                            self.state = "DIALOGUE"
                            self.dialogue_name = "System"
                            self.dialogue_text = "Falscher Code!"
                        self.input_text = ""
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_text = self.input_text[:-1]
                    elif event.unicode.isdigit():
                        self.input_text += event.unicode
                    elif event.key == pygame.K_ESCAPE:
                        self.state = "EXPLORING"
                        self.input_text = ""
                elif self.state == "DECISION":
                    if pygame.K_1 <= event.key <= pygame.K_9:
                        idx = event.key - pygame.K_1
                        if idx < len(self.npcs):
                            self.selected_suspect = self.npcs[idx].name
                            self.state = "ENDING"
                    if event.key == pygame.K_ESCAPE:
                        self.state = "EXPLORING"
                elif self.state == "ENDING":
                    if event.key == pygame.K_r:
                        self.__init__()

    def get_house_clue(self, house_name):
        clues = {
            "Stadtarchiv": "Alte Münzen",
            "Haus von Wache Ulrich": "Blaue Feder",
            "Lottes Laden": "Lavendel-Fläschchen",
            "Bäckerei": "Mehl-Fußspuren",
            "Schatzkammer": "Leeres Podest"
        }
        return clues.get(house_name, "Nichts")

    def evaluate_suspect(self):
        if self.selected_suspect == self.correct_suspect:
            return "Richtig. Du hast den Täter entlarvt."
        return f"Leider falsch. Der wahre Täter war {self.correct_suspect}."

    def enter_interior(self, house_name):
        self.last_overworld_pos = (self.player.rect.x, self.player.rect.y)
        self.current_interior = house_name
        self.state = "INTERIOR"
        # Spieler im Innenraum platzieren (Zentrum)
        interior_positions = {
            "Stadtarchiv": (WIDTH // 2, HEIGHT // 2 + 20),
            "Lottes Laden": (WIDTH // 2, HEIGHT // 2 + 20),
            "Bäckerei": (WIDTH // 2, HEIGHT // 2 + 20),
            "Schatzkammer": (WIDTH // 2, HEIGHT // 2 + 40)
        }
        self.player.rect.x, self.player.rect.y = interior_positions.get(house_name, (WIDTH // 2, HEIGHT - 100))

    def exit_interior(self):
        self.state = "EXPLORING"
        self.player.rect.x, self.player.rect.y = self.last_overworld_pos
        self.player.rect.y += 50 
        self.current_interior = None

    def interact(self):
        if self.state == "INTERIOR":
            # Ausgang prüfen
            exit_rect = pygame.Rect(WIDTH // 2 - 50, HEIGHT - 20, 100, 20)
            if self.player.rect.colliderect(exit_rect):
                self.exit_interior()
                return
            
            # NPCs im Innenraum prüfen
            for npc in self.npcs:
                if npc.data.get('interior') == self.current_interior:
                    if self.player.rect.inflate(20, 20).colliderect(npc.rect):
                        self.state = "DIALOGUE"
                        self.dialogue_name = npc.name
                        self.dialogue_text = npc.data['statement']
                        self.current_npc = npc
                        self.dialogue_step = 0
                        return
            
            # Hinweise im Innenraum prüfen
            for clue in self.clues:
                if clue.data.get('interior') == self.current_interior:
                    if self.player.rect.inflate(20, 20).colliderect(clue.rect):
                        self.state = "DIALOGUE"
                        self.dialogue_name = clue.title
                        self.dialogue_text = clue.data['description']
                        if clue.title not in self.inventory:
                            self.inventory.append(clue.title)
                            self.inventory_full_data.append({"title": clue.title, "description": clue.data['description']})
                        clue.collected = True
                        return
            return

        # --- OBERWELT INTERAKTIONEN ---

        # 1. Grabstein-Rätsel auf dem Friedhof
        if not self.gravestone_moved:
            # Wir nehmen einen speziellen Grabstein (z.B. den ersten auf dem Friedhof)
            special_gravestone = self.gravestones[0]
            if self.player.rect.inflate(20, 20).colliderect(special_gravestone):
                self.state = "DIALOGUE"
                self.dialogue_name = "Grabstein"
                self.dialogue_text = "Du schiebst den schweren Stein beiseite... darunter liegt ein Geheimgang zu den Tresoren!"
                self.gravestone_moved = True
                return
        
        # Geheimgang betreten (wenn Stein verschoben und Animation fertig)
        if self.gravestone_anim_done:
            special_gravestone = self.gravestones[0]
            if self.player.rect.colliderect(special_gravestone):
                self.enter_interior("Schatzkammer")
                return

        # 2. Prüfen auf Haus-Eingänge
        for name, rect in self.entrances.items():
            if self.player.rect.inflate(10, 10).colliderect(rect):
                if name in self.unlocked_houses or self.house_codes.get(name) == "OFFEN":
                    self.enter_interior(name)
                else:
                    self.state = "CODE_ENTRY"
                    self.target_house = name
                    self.input_text = ""
                return

        # 3. Prüfen auf Bootshaus
        if self.player.rect.inflate(20, 20).colliderect(self.boathouse):
            if "Schlüssel" in self.inventory:
                self.state = "DIALOGUE"
                self.dialogue_name = "Bootshaus"
                self.dialogue_text = "Du nutzt den Schlüssel. Das Boot ist nun bereit!"
                self.has_boat_access = True
                if self.river in self.walls:
                    self.walls.remove(self.river)
            else:
                self.state = "DIALOGUE"
                self.dialogue_name = "Bootshaus"
                self.dialogue_text = "Die Tür ist verschlossen. Du brauchst einen Schlüssel."
            return

        # 4. Prüfen auf NPCs
        for npc in self.npcs:
            if self.player.rect.inflate(20, 20).colliderect(npc.rect):
                # Speziallogik für Polizist (Finale)
                if npc.name == "Polizist":
                    if len(self.unlocked_houses) >= 4:
                        self.state = "DECISION"
                        return
                    # Wenn noch nicht alle Häuser offen sind, normaler Dialog
                    self.state = "DIALOGUE"
                    self.dialogue_name = npc.name
                    self.dialogue_text = npc.data['statement']
                    self.current_npc = npc
                    self.dialogue_step = 0
                    return

                self.state = "DIALOGUE"
                self.dialogue_name = npc.name
                self.current_npc = npc
                self.dialogue_step = 0
                
                # Speziallogik für Lügen/Gegenstände
                if npc.name == "Händlerin Lotte" and "Verschlammte Stiefel" in self.inventory:
                    self.dialogue_text = "Oh! Diese Stiefel... okay, ich gebe es zu. Ich war nachts draußen, aber nur um Vorräte zu holen!"
                    if "Geheimes Notizbuch" not in self.inventory:
                        self.inventory.append("Geheimes Notizbuch")
                        self.inventory_full_data.append({"title": "Geheimes Notizbuch", "description": "Ein Notizbuch von Lotte. Es enthält eine Liste von Kunden, aber Ulrichs Name ist durchgestrichen."})
                    self.current_npc = None # Keine Details nach Spezialdialog
                elif npc.name == "Wache Ulrich" and "Zerrissene Karte" in self.inventory:
                    self.dialogue_text = "Wo hast du das her? Das ist eine Skizze der alten Tunnel. Ich habe sie gefunden und wollte sie der Bibliothekarin bringen."
                    self.current_npc = None # Keine Details nach Spezialdialog
                else:
                    self.dialogue_text = npc.data['statement']
                return
        
        # 5. Prüfen auf Hinweise (nur in der Oberwelt)
        for clue in self.clues:
            if not clue.data.get('interior'):
                if self.player.rect.inflate(20, 20).colliderect(clue.rect):
                    self.state = "DIALOGUE"
                    self.dialogue_name = clue.title
                    self.dialogue_text = clue.data['description']
                    if clue.title not in self.inventory:
                        self.inventory.append(clue.title)
                        self.inventory_full_data.append({"title": clue.title, "description": clue.data['description']})
                    clue.collected = True
                    return

    def update(self):
        # Gesammelte Hinweise entfernen
        self.clues = [c for c in self.clues if not getattr(c, 'collected', False)]

        # Grabstein-Animation
        if self.gravestone_moved and not self.gravestone_anim_done:
            if self.gravestone_y_offset > -40:
                self.gravestone_y_offset -= 1
            else:
                self.gravestone_anim_done = True
                special_gravestone = self.gravestones[0]
                self.clues.append(Clue(self.clue_data[9]['title'], special_gravestone.x + 40, special_gravestone.y, self.clue_data[9]))
        
        if self.state == "EXPLORING":
            keys = pygame.key.get_pressed()
            
            # Kollisionsliste filtern: Wenn der Stein verschoben ist, ignorieren wir ihn bei der Kollision
            collision_walls = self.walls
            if self.gravestone_anim_done:
                collision_walls = [w for w in self.walls if w != self.gravestones[0]]
                
            self.player.move(keys, collision_walls)
            self.camera.update(self.player)
        elif self.state == "INTERIOR":
            keys = pygame.key.get_pressed()
            # Im Innenraum gibt es keine Kamera-Bewegung und andere Wände
            walls = [
                pygame.Rect(0, 0, WIDTH, 50), # Oben
                pygame.Rect(0, 0, 50, HEIGHT), # Links
                pygame.Rect(WIDTH - 50, 0, 50, HEIGHT), # Rechts
                pygame.Rect(0, HEIGHT - 10, WIDTH, 10) # Unten
            ]
            # Zusätzliche Möbel-Kollision im Innenraum
            if self.current_interior in self.interior_objects:
                for obj in self.interior_objects[self.current_interior]:
                    walls.append(obj["rect"])
            
            self.player.move(keys, walls)

    def draw(self):
        if self.state == "INTRO":
            self.screen.fill((20, 20, 30))
            intro_lines = [
                "Willkommen in Heldenhain.",
                "",
                "Ein wertvolles Artefakt wurde gestohlen.",
                "Die Stadt ist in Aufruhr.",
                "Sprechen Sie mit den Bewohnern und finden Sie Hinweise.",
                "Aber Vorsicht: Jeder sieht nur einen Teil der Wahrheit.",
                "",
                "Drücken Sie LEERTASTE zum Starten..."
            ]
            for i, line in enumerate(intro_lines):
                text = self.font.render(line, True, (255, 255, 255))
                self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 200 + i * 40))
            return

        self.screen.fill((100, 110, 120))  # Blaugrau
        
        # Wege zeichnen
        for path in self.paths:
            pygame.draw.rect(self.screen, (120, 100, 80), self.camera.apply_rect(path))

        # Marktplatz zeichnen
        pygame.draw.rect(self.screen, (130, 130, 130), self.camera.apply_rect(self.marketplace))
        pygame.draw.circle(self.screen, (50, 100, 200), self.camera.apply_rect(self.marketplace).center, 40) # Brunnen
        
        # Friedhof zeichnen
        pygame.draw.rect(self.screen, (80, 90, 80), self.camera.apply_rect(self.cemetery))

        # Fluss zeichnen
        pygame.draw.rect(self.screen, (50, 100, 200), self.camera.apply_rect(self.river))
        
        # Laternen zeichnen
        for lantern in self.lanterns:
            rect = self.camera.apply_rect(lantern)
            pygame.draw.rect(self.screen, (80, 40, 20), rect)
            pygame.draw.circle(self.screen, (255, 220, 100), (rect.centerx, rect.top + 8), 6)
            pygame.draw.circle(self.screen, (255, 180, 50), (rect.centerx, rect.top + 8), 3)

        # Wände/Felsen/Bäume zeichnen
        for wall in self.walls:
            if wall != self.river:
                if wall in self.trees:
                    # Baum zeichnen (Grün mit braunem Stamm)
                    rect = self.camera.apply_rect(wall)
                    pygame.draw.rect(self.screen, (100, 70, 30), (rect.centerx - 5, rect.bottom - 10, 10, 10))
                    pygame.draw.circle(self.screen, (34, 139, 34), (rect.centerx, rect.centery - 5), 20)
                elif wall in self.gravestones:
                    rect = self.camera.apply_rect(wall)
                    # Spezial-Animation für den ersten Grabstein
                    if wall == self.gravestones[0]:
                        # Geheimgang darunter zeichnen (Dunkles Loch)
                        if self.gravestone_moved:
                            # Wir zeichnen ein festes schwarzes Quadrat an der ursprünglichen Position
                            original_rect = self.camera.apply_rect(wall)
                            pygame.draw.rect(self.screen, (0, 0, 0), original_rect)
                        
                        # Der Stein selbst wird versetzt gezeichnet
                        rect.y += self.gravestone_y_offset
                    
                    pygame.draw.rect(self.screen, (150, 150, 150), rect)
                    pygame.draw.rect(self.screen, (80, 80, 80), rect, 2)
                    
                    # Kreuzfarbe bestimmen (Tiefschwarz für den speziellen Stein)
                    cross_color = (0, 0, 0) if wall == self.gravestones[0] else (80, 80, 80)
                    cross_width = 3 if wall == self.gravestones[0] else 2
                    
                    pygame.draw.line(self.screen, cross_color, (rect.centerx, rect.top + 10), (rect.centerx, rect.bottom - 10), cross_width)
                    pygame.draw.line(self.screen, cross_color, (rect.left + 10, rect.centery), (rect.right - 10, rect.centery), cross_width)
                elif wall in self.houses.values() or wall == self.boathouse:
                    # Häuser/Bootshaus
                    pygame.draw.rect(self.screen, (60, 60, 60), self.camera.apply_rect(wall))
                    pygame.draw.rect(self.screen, (40, 40, 40), self.camera.apply_rect(wall), 2)
                else:
                    # Nur die äußeren Weltgrenzen zeichnen
                    rect = self.camera.apply_rect(wall)
                    # Prüfen ob es eine Weltgrenze ist (sehr breit oder sehr hoch)
                    if wall.width > WORLD_WIDTH - 100 or wall.height > WORLD_HEIGHT - 100:
                        pygame.draw.rect(self.screen, (60, 60, 60), rect)
                        pygame.draw.rect(self.screen, (40, 40, 40), rect, 2)
        
        # Bootshaus speziell markieren
        pygame.draw.rect(self.screen, (100, 50, 0), self.camera.apply_rect(self.boathouse))

        # Eingänge zeichnen
        for name, rect in self.entrances.items():
            color = (0, 255, 0) if name in self.unlocked_houses else (0, 150, 0)
            pygame.draw.rect(self.screen, color, self.camera.apply_rect(rect))

        # NPCs, Hinweise und Spieler nur in der Oberwelt zeichnen
        if self.state != "INTERIOR":
            for npc in self.npcs:
                # Nur NPCs ohne Innenraum in der Oberwelt zeichnen
                if not npc.data.get('interior'):
                    npc.draw(self.screen, self.camera)
            for clue in self.clues:
                # Nur Hinweise ohne Innenraum in der Oberwelt zeichnen
                if not clue.data.get('interior'):
                    clue.draw(self.screen, self.camera)
            self.player.draw(self.screen, self.camera)

        # UI
        boat_status = "Boot bereit" if self.has_boat_access else "Boot verschlossen"
        ui_text = f"Häuser: {len(self.unlocked_houses)}/{self.unlock_target} | {boat_status} | WASD: Bewegen | E: Interagieren | I: Inventar"
        text_surf = self.font.render(ui_text, True, (255, 255, 255))
        self.screen.blit(text_surf, (20, 20))

        if self.state == "INTERIOR":
            self.draw_interior()

        if self.state == "DIALOGUE":
            self.draw_dialogue()
        elif self.state == "CODE_ENTRY":
            self.draw_code_entry()
        elif self.state == "DECISION":
            self.draw_decision()
        elif self.state == "ENDING":
            self.draw_ending()
            
        if self.show_inventory:
            self.draw_inventory()

    def draw_interior(self):
        self.screen.fill((50, 40, 30)) # Dunkles Holz/Boden
        # Wände zeichnen
        pygame.draw.rect(self.screen, (80, 60, 40), (0, 0, WIDTH, 50)) # Oben
        pygame.draw.rect(self.screen, (80, 60, 40), (0, 0, 50, HEIGHT)) # Links
        pygame.draw.rect(self.screen, (80, 60, 40), (WIDTH - 50, 0, 50, HEIGHT)) # Rechts
        
        # Möbel zeichnen
        if self.current_interior in self.interior_objects:
            for obj in self.interior_objects[self.current_interior]:
                rect = obj["rect"]
                color = obj["color"]
                pygame.draw.rect(self.screen, color, rect)
                
                # Details hinzufügen (Maserung/Struktur)
                border_color = (max(0, color[0]-40), max(0, color[1]-40), max(0, color[2]-40))
                light_color = (min(255, color[0]+20), min(255, color[1]+20), min(255, color[2]+20))
                
                # Rahmen
                pygame.draw.rect(self.screen, border_color, rect, 2)
                
                if obj["label"] in ["Verkaufstheke", "Backtheke", "Bücherregal", "Regal"]:
                    # Holzmaserung (horizontale Linien)
                    for i in range(4, rect.height, 12):
                        pygame.draw.line(self.screen, border_color, (rect.left + 4, rect.top + i), (rect.right - 4, rect.top + i), 1)
                    # Vertikale Bretter-Optik
                    for i in range(40, rect.width, 40):
                        pygame.draw.line(self.screen, border_color, (rect.left + i, rect.top), (rect.left + i, rect.bottom), 1)
                
                if obj["label"] == "Ofen":
                    # Ofentür
                    door_rect = pygame.Rect(rect.centerx - 20, rect.centery - 10, 40, 30)
                    pygame.draw.rect(self.screen, (30, 30, 30), door_rect)
                    pygame.draw.rect(self.screen, (10, 10, 10), door_rect, 2)
                    # Glühen-Effekt (kleiner Punkt)
                    pygame.draw.circle(self.screen, (200, 50, 0), (door_rect.centerx, door_rect.centery), 4)
                
                if obj["label"] == "Mehlsack-Stapel":
                    # Unterteilung in einzelne Säcke
                    pygame.draw.line(self.screen, border_color, (rect.left, rect.centery), (rect.right, rect.centery), 2)
                    pygame.draw.circle(self.screen, light_color, (rect.centerx - 10, rect.top + 15), 5)
                    pygame.draw.circle(self.screen, light_color, (rect.centerx + 10, rect.bottom - 15), 5)

        # Ausgang markieren
        pygame.draw.rect(self.screen, (100, 80, 60), (WIDTH // 2 - 50, HEIGHT - 20, 100, 20))
        
        title = self.font.render(f"Innenraum: {self.current_interior}", True, (255, 255, 255))
        self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 20))
        
        # NPCs im Innenraum zeichnen
        for npc in self.npcs:
            if npc.data.get('interior') == self.current_interior:
                npc.draw(self.screen, None)
        
        # Hinweise im Innenraum zeichnen
        for clue in self.clues:
            if clue.data.get('interior') == self.current_interior:
                clue.draw(self.screen, None)
        
        # Spieler zeichnen (ohne Kamera-Apply, da fixiert)
        self.player.draw(self.screen, None)
        
        hint = self.font.render("Gehe nach unten, um das Haus zu verlassen", True, (150, 150, 150))
        self.screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, HEIGHT - 60))

    def draw_dialogue(self):
        # Hintergrundbox
        pygame.draw.rect(self.screen, (0, 0, 0), (50, HEIGHT - 200, WIDTH - 100, 150))
        pygame.draw.rect(self.screen, (255, 255, 255), (50, HEIGHT - 200, WIDTH - 100, 150), 2)
        
        # Name
        name_surf = self.font.render(self.dialogue_name, True, (255, 255, 0))
        self.screen.blit(name_surf, (70, HEIGHT - 180))
        
        # Text (einfacher Zeilenumbruch)
        words = self.dialogue_text.split(' ')
        lines = []
        current_line = ""
        for word in words:
            if self.font.size(current_line + word)[0] < WIDTH - 150:
                current_line += word + " "
            else:
                lines.append(current_line)
                current_line = word + " "
        lines.append(current_line)
        
        for i, line in enumerate(lines[:3]):
            text_surf = self.font.render(line, True, (255, 255, 255))
            self.screen.blit(text_surf, (70, HEIGHT - 140 + i * 30))

    def draw_code_entry(self):
        pygame.draw.rect(self.screen, (0, 0, 0), (WIDTH // 2 - 150, HEIGHT // 2 - 100, 300, 200))
        pygame.draw.rect(self.screen, (255, 255, 255), (WIDTH // 2 - 150, HEIGHT // 2 - 100, 300, 200), 2)
        
        title = self.font.render(f"Code für {self.target_house}:", True, (255, 255, 255))
        self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 70))
        
        code_surf = self.font.render(self.input_text + "_", True, (255, 255, 0))
        self.screen.blit(code_surf, (WIDTH // 2 - code_surf.get_width() // 2, HEIGHT // 2))
        
        hint = self.font.render("ENTER zum Bestätigen", True, (150, 150, 150))
        self.screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, HEIGHT // 2 + 50))

    def draw_inventory(self):
        # Overlay
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        
        # Box
        pygame.draw.rect(self.screen, (50, 50, 70), (WIDTH // 2 - 200, 100, 400, 550))
        pygame.draw.rect(self.screen, (255, 255, 255), (WIDTH // 2 - 200, 100, 400, 550), 2)
        
        title = self.font.render("INVENTAR", True, (255, 255, 0))
        self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 120))
        
        if not self.inventory:
            empty = self.font.render("Leer", True, (150, 150, 150))
            self.screen.blit(empty, (WIDTH // 2 - empty.get_width() // 2, 250))
        else:
            for i, item in enumerate(self.inventory):
                color = (255, 255, 255)
                prefix = "- "
                if i == self.inventory_index:
                    color = (255, 255, 0) # Gelb für Auswahl
                    prefix = "> "
                
                item_surf = self.font.render(f"{prefix}{item}", True, color)
                self.screen.blit(item_surf, (WIDTH // 2 - 150, 180 + i * 40))
            
            hint = self.font.render("Pfeiltasten: Wählen | ENTER: Ansehen", True, (150, 150, 150))
            self.screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, 600))

    def draw_decision(self):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 200))
        self.screen.blit(overlay, (0, 0))
        
        title = self.font.render("WEN BESCHULDIGEN SIE?", True, (255, 0, 0))
        self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 100))
        
        for i, npc in enumerate(self.npcs):
            text = f"{i+1}: {npc.name}"
            color = (255, 255, 255)
            surf = self.font.render(text, True, color)
            self.screen.blit(surf, (WIDTH // 2 - 100, 180 + i * 40))

    def draw_ending(self):
        self.screen.fill((0, 0, 0))
        title = self.font.render("FALL ABGESCHLOSSEN", True, (255, 255, 0))
        self.screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 200))
        
        result = f"Sie haben {self.selected_suspect} beschuldigt."
        res_surf = self.font.render(result, True, (255, 255, 255))
        self.screen.blit(res_surf, (WIDTH // 2 - res_surf.get_width() // 2, 300))
        
        evaluation = self.evaluate_suspect()
        evaluation_surf = self.font.render(evaluation, True, (200, 200, 0))
        self.screen.blit(evaluation_surf, (WIDTH // 2 - evaluation_surf.get_width() // 2, 360))
        
        moral = "Jede Entscheidung war nur eine Deutung aus begrenzten Informationen."
        moral_surf = self.font.render(moral, True, (150, 150, 150))
        self.screen.blit(moral_surf, (WIDTH // 2 - moral_surf.get_width() // 2, 430))
        
        restart = "Drücken Sie 'R' für einen Neustart"
        rest_surf = self.font.render(restart, True, (100, 255, 100))
        self.screen.blit(rest_surf, (WIDTH // 2 - rest_surf.get_width() // 2, 500))

    async def run(self):
        while True:
            self.handle_events()
            self.update()
            self.draw()
            pygame.display.flip()
            self.clock.tick(FPS)
            await asyncio.sleep(0) # Wichtig für pygbag/Web-Browser

async def main():
    print("Starte MysteryTown Web-Engine...")
    try:
        game = Game()
        print("Spiel-Objekt erstellt, starte Loop...")
        await game.run()
    except Exception as e:
        print(f"KRITISCHER FEHLER BEIM START: {e}")
        # Fehler im Browser-Fenster anzeigen (falls möglich)
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
