"""Minimal PDF reader scaffold for MysteryTown.

This module provides lightweight helpers to load PDF bytes and small utilities
we'll expand to extract ToUnicode CMaps and page text streams without external
dependencies. Functions are intentionally small and documented so we can extend
them progressively.
"""
from typing import Optional, Dict, List
import re


def load_pdf_bytes(path: str) -> bytes:
    """Load a PDF file and return its raw bytes."""
    with open(path, "rb") as f:
        return f.read()


def find_objects(pdf_bytes: bytes) -> List[bytes]:
    """Return a simple list of object byte ranges found by ' obj' markers.

    This is a naive parser intended for controlled PDFs in the project. It
    does not replace a full PDF parser but is sufficient for targeted
    extraction (ToUnicode, page content streams).
    """
    # Find occurrences of '\n<number> 0 obj' and split roughly.
    objs = re.split(rb"\n\d+\s+0\s+obj", pdf_bytes)
    # First part is header, remaining are objects (with the header trimmed).
    return objs[1:]


def extract_page_streams(pdf_bytes: bytes) -> List[bytes]:
    """Extract candidate page content streams (raw stream ... endstream).

    Returns list of raw stream bytes (may still be compressed).
    """
    streams = re.findall(rb"stream\r?\n(.*?)\r?\nendstream", pdf_bytes, flags=re.S)
    return streams


def simple_decompress(data: bytes) -> Optional[bytes]:
    """Try zlib decompression, return None if it fails."""
    import zlib

    try:
        return zlib.decompress(data)
    except Exception:
        return None


def parse_tounicode_cmaps(pdf_bytes: bytes) -> Dict[int, Dict[int, str]]:
    """Parse simple ToUnicode CMaps from the PDF and return mappings.

    Returns a dict keyed by object number (approximate) with value a mapping
    from character code (0-255) to a Unicode character.
    """
    cmaps: Dict[int, Dict[int, str]] = {}
    # Find candidate ToUnicode streams containing 'beginbfchar' or 'beginbfrange'
    for m in re.finditer(rb"(\d+)\s+0\s+obj(.*?)endobj", pdf_bytes, flags=re.S):
        header_num = int(m.group(1))
        body = m.group(2)
        if b"beginbfchar" in body or b"beginbfrange" in body:
            mapping: Dict[int, str] = {}
            # parse lines like <01> <0041>
            for bf in re.finditer(rb"<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>", body):
                src = bytes.fromhex(bf.group(1).decode())
                dst = bytes.fromhex(bf.group(2).decode())
                # only handle single-byte source for now
                if len(src) == 1:
                    code = src[0]
                    try:
                        char = dst.decode('utf-16-be')
                    except Exception:
                        try:
                            char = dst.decode('utf-8', errors='replace')
                        except Exception:
                            char = '?'
                    mapping[code] = char
            if mapping:
                cmaps[header_num] = mapping
    return cmaps


def extract_text_candidates(page_bytes: bytes) -> List[str]:
    """Return human-readable text snippets from a page content stream.

    This attempts to locate TJ/Tj text operators and return raw string tokens.
    It does not yet apply ToUnicode mapping.
    """
    results: List[str] = []
    # literal strings (..)
    for m in re.finditer(rb"\((.*?)\)", page_bytes, flags=re.S):
        raw = m.group(1)
        try:
            results.append(raw.decode('latin-1'))
        except Exception:
            results.append(raw.decode('latin-1', errors='replace'))

    # hex string tokens like <0102>
    for m in re.finditer(rb"<([0-9A-Fa-f]+)>", page_bytes, flags=re.S):
        hexdata = m.group(1)
        try:
            b = bytes.fromhex(hexdata.decode())
            results.append(b.decode('latin-1'))
        except Exception:
            # fallback: include raw hex as text
            try:
                results.append(hexdata.decode())
            except Exception:
                results.append(str(hexdata))

    # Also attempt to extract TJ arrays and split numbers/spacings out
    for m in re.finditer(rb"\[(.*?)\]\s*TJ", page_bytes, flags=re.S):
        content = m.group(1)
        # extract any hex groups inside the array
        for hm in re.finditer(rb"<([0-9A-Fa-f]+)>", content):
            try:
                b = bytes.fromhex(hm.group(1).decode())
                results.append(b.decode('latin-1'))
            except Exception:
                try:
                    results.append(hm.group(1).decode())
                except Exception:
                    results.append(str(hm.group(1)))

    return results


def apply_cmap_to_bytes(raw: bytes, cmap: Dict[int, str]) -> str:
    """Apply a simple single-byte ToUnicode cmap to raw bytes."""
    out = []
    for b in raw:
        if b in cmap:
            out.append(cmap[b])
        else:
            out.append(chr(b))
    return ''.join(out)


def extract_structured_text(pdf_path: str) -> Dict[str, List[str]]:
    """High-level helper: load PDF, parse cmaps, extract page text tokens.

    Returns a dict with keys 'raw_tokens' and 'mapped_tokens' for convenience.
    """
    b = load_pdf_bytes(pdf_path)
    cmaps = parse_tounicode_cmaps(b)
    merged_cmap: Dict[int, str] = {}
    # merge all cmaps, later mappings win
    for m in cmaps.values():
        merged_cmap.update(m)

    streams = extract_page_streams(b)
    raw_tokens: List[str] = []
    mapped_tokens: List[str] = []
    for s in streams:
        dec = simple_decompress(s)
        source = dec if dec is not None else s
        tokens = extract_text_candidates(source)
        for t in tokens:
            raw_tokens.append(t)
            # try mapping by interpreting token as latin-1 bytes
            try:
                mapped = apply_cmap_to_bytes(t.encode('latin-1'), merged_cmap)
            except Exception:
                mapped = t
            mapped_tokens.append(mapped)

        # also look for readable ASCII/Latin-1 sequences in the stream
        for m in re.finditer(rb"[\x20-\x7E\xA0-\xFF]{4,}", source):
            try:
                txt = m.group(0).decode('latin-1')
            except Exception:
                txt = m.group(0).decode('latin-1', errors='replace')
            # filter out long numeric-only sequences
            if re.search(r"[A-Za-zÄÖÜäöüß]", txt):
                mapped_tokens.append(txt)
                raw_tokens.append(txt)

    return {"raw_tokens": raw_tokens, "mapped_tokens": mapped_tokens}


def save_extraction(pdf_path: str, out_path: str) -> None:
    """Run extraction and save a compact JSON of unique readable tokens."""
    import json

    out = extract_structured_text(pdf_path)
    seen = []
    sset = set()
    for t in out['mapped_tokens']:
        if not t or t.isspace():
            continue
        if not re.search(r"[A-Za-zÄÖÜäöüß]", t):
            continue
        if t in sset:
            continue
        sset.add(t)
        seen.append(t)

    payload = {
        'source': pdf_path,
        'count': len(seen),
        'tokens': seen,
    }
    with open(out_path, 'w', encoding='utf-8') as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)



if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: pdf_reader.py <path-to-pdf>")
        sys.exit(1)
    path = sys.argv[1]
    b = load_pdf_bytes(path)
    print(f"Loaded {len(b)} bytes from {path}")
    streams = extract_page_streams(b)
    print(f"Found {len(streams)} candidate streams")
    # show first few snippets
    if streams:
        print("Extracting structured text (this may try ToUnicode mappings):")
        out = extract_structured_text(path)
        print(f"Raw tokens: {len(out['raw_tokens'])}, Mapped tokens: {len(out['mapped_tokens'])}")
        seen = set()
        printed = 0
        for t in out['mapped_tokens']:
            if not t or t.isspace():
                continue
            if not re.search(r"[A-Za-zÄÖÜäöüß]", t):
                continue
            if t in seen:
                continue
            seen.add(t)
            print('-', t)
            printed += 1
            if printed >= 60:
                break
