"""Generate suggested clue entries from extracted PDF tokens.

Produces `data/suggested_clues.json` with candidate clues for review.
"""
import json
import re
from pathlib import Path


KEYWORDS = [
    "code",
    "Code",
    "Stadtarchiv",
    "Bootshaus",
    "Schatzkammer",
    "Schlüssel",
    "Lavendel",
    "Kästchen",
    "Kästchen",
    "Zettel",
    "Hinweis",
    "Notiz",
    "Karte",
    "Brunnen",
    "Marktplatz",
    "Haus",
]


def load_json(path: Path):
    with path.open('r', encoding='utf-8') as fh:
        return json.load(fh)


def save_json(path: Path, data):
    with path.open('w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def normalize(s: str) -> str:
    return re.sub(r"\s+", ' ', s).strip()


def make_suggestions():
    base = Path(__file__).resolve().parent
    extracted = load_json(base / 'data' / 'extracted_story.json')
    existing = load_json(base / 'data' / 'clues.json')

    existing_texts = {normalize(c.get('title','')+ ' ' + c.get('description','')) for c in existing}

    tokens = extracted.get('tokens', [])
    suggestions = []
    seen = set()

    for t in tokens:
        for kw in KEYWORDS:
            if kw.lower() in t.lower():
                text = normalize(t)
                if text in seen:
                    continue
                seen.add(text)
                # create a short title
                title = None
                m = re.search(r"(code[:\s]*\d{3,6})", t, flags=re.IGNORECASE)
                if m:
                    title = f"Code: {m.group(1).split(':')[-1].strip()}"
                else:
                    # use first few words as title
                    title = 'Hinweis: ' + ' '.join(text.split()[:6])

                candidate = {
                    'title': title,
                    'description': text,
                }

                # avoid exact duplicates with existing clues
                if normalize(candidate['title'] + ' ' + candidate['description']) in existing_texts:
                    continue

                suggestions.append(candidate)
                break

    out_path = base / 'data' / 'suggested_clues.json'
    save_json(out_path, {'count': len(suggestions), 'suggestions': suggestions})
    return out_path, len(suggestions)


if __name__ == '__main__':
    p, n = make_suggestions()
    print(f'Wrote {n} suggestions to {p}')
