"""Decode page text using ToUnicode CMaps for targeted TJ hex sequences.

Produces `data/decoded_texts.json` with decoded lines for manual review.
"""
from pathlib import Path
import re, zlib, json


def load_pdf(path: Path) -> bytes:
    return path.read_bytes()


def extract_obj_body(pdf_bytes: bytes, obj_num: int) -> bytes | None:
    m = re.search(rb"%d\s+0\s+obj(.*?)endobj" % obj_num, pdf_bytes, flags=re.S)
    return m.group(1) if m else None


def extract_stream(body: bytes) -> bytes | None:
    m = re.search(rb"stream\r?\n(.*?)\r?\nendstream", body, flags=re.S)
    return m.group(1) if m else None


def parse_cmap_from_obj(body: bytes) -> dict:
    mapping = {}
    try:
        stream = extract_stream(body)
        if not stream:
            text = body
        else:
            try:
                text = zlib.decompress(stream)
            except Exception:
                text = stream

        # find <xx> <yyyy> pairs
        for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>", text):
            src = bytes.fromhex(m.group(1).decode())
            dst = bytes.fromhex(m.group(2).decode())
            if len(src) == 1:
                code = src[0]
                try:
                    char = dst.decode('utf-16-be')
                except Exception:
                    char = dst.decode('latin-1', errors='replace')
                mapping[code] = char

        # handle bfrange entries: <start> <end> <dstStart> or <start> <end> [<d1> <d2> ...]
        for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>\s+(<([0-9A-Fa-f]+)>|\[([^\]]+)\])", text):
            start_src = int(m.group(1), 16)
            end_src = int(m.group(2), 16)
            if m.group(3).startswith(b'<'):
                dst_start = int(m.group(4), 16)
                for i, src_code in enumerate(range(start_src, end_src+1)):
                    dst_code = dst_start + i
                    try:
                        char = bytes.fromhex(f"{dst_code:04x}").decode('utf-16-be')
                    except Exception:
                        char = chr(dst_code)
                    mapping[src_code] = char
            else:
                arr = m.group(5)
                # find all <xxxx> in array
                dlist = re.findall(rb"<([0-9A-Fa-f]+)>", arr)
                for i, src_code in enumerate(range(start_src, min(end_src+1, start_src+len(dlist)))):
                    dst_code = int(dlist[i], 16)
                    try:
                        char = bytes.fromhex(f"{dst_code:04x}").decode('utf-16-be')
                    except Exception:
                        char = chr(dst_code)
                    mapping[src_code] = char
    except Exception:
        pass
    return mapping


def build_merged_cmap(pdf_bytes: bytes, obj_ids: list) -> dict:
    cmap = {}
    for oid in obj_ids:
        body = extract_obj_body(pdf_bytes, oid)
        if not body:
            continue
        mapping = parse_cmap_from_obj(body)
        cmap.update(mapping)
    return cmap


def decode_tj_hex_sequence(hex_groups: list, cmap: dict) -> str:
    # hex_groups are strings like '01' or '0102'
    out = []
    for hg in hex_groups:
        try:
            b = bytes.fromhex(hg)
        except Exception:
            continue
        for by in b:
            out.append(cmap.get(by, chr(by)))
    return ''.join(out)


def decode_stream_texts(pdf_bytes: bytes, cmap: dict) -> list:
    texts = []
    streams = re.findall(rb"stream\r?\n(.*?)\r?\nendstream", pdf_bytes, flags=re.S)
    for s in streams:
        dec = None
        try:
            dec = zlib.decompress(s)
            source = dec
        except Exception:
            source = s

        # find TJ arrays with hex groups
        for m in re.finditer(rb"\[([^\]]*?)\]\s*TJ", source, flags=re.S):
            arr = m.group(1)
            hex_groups = [hg.decode() for hg in re.findall(rb"<([0-9A-Fa-f]+)>", arr)]
            if hex_groups:
                decoded = decode_tj_hex_sequence(hex_groups, cmap)
                if decoded.strip():
                    texts.append(decoded)

        # also find single hex strings like <0102> Tj
        for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s*Tj", source):
            hg = m.group(1).decode()
            decoded = decode_tj_hex_sequence([hg], cmap)
            if decoded.strip():
                texts.append(decoded)

    return texts


def main():
    pdf = Path('MysteryTown_Storyline_Wahrheitssiegel_Langfassung.pdf')
    b = load_pdf(pdf)
    # known ToUnicode object refs from earlier analysis
    obj_ids = [769, 774, 779]
    cmap = build_merged_cmap(b, obj_ids)
    texts = decode_stream_texts(b, cmap)
    out = {'decoded_count': len(texts), 'decoded': texts}
    Path('data').mkdir(exist_ok=True)
    with open(Path('data') / 'decoded_texts.json', 'w', encoding='utf-8') as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print('Wrote', len(texts), 'decoded texts to data/decoded_texts.json')


if __name__ == '__main__':
    main()
