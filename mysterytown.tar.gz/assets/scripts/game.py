import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def load_json(filename):
    path = BASE_DIR / filename
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def print_intro():
    intro_path = BASE_DIR / 'story' / 'intro.txt'
    with open(intro_path, encoding='utf-8') as f:
        print(f.read())


def ask_choice(prompt, choices):
    for index, choice in enumerate(choices, start=1):
        print(f"{index}. {choice}")

    while True:
        selection = input(prompt).strip()
        if selection.isdigit() and 1 <= int(selection) <= len(choices):
            return int(selection) - 1
        print("Bitte gib eine Zahl ein, die zu den Optionen passt.")


def talk_to_npc(npc):
    print(f"\nDu sprichst mit {npc['name']}.\n")
    print(npc['statement'])
    if npc.get('detail'):
        follow_up = ask_choice("Möchtest du nachfragen? ", ["Nein", "Ja"])
        if follow_up == 1:
            print(npc['detail'])


def search_clue(clue):
    print(f"\nHinweis: {clue['title']}")
    print(clue['description'])


def main():
    print_intro()
    characters = load_json('data/characters.json')
    clues = load_json('data/clues.json')

    print("Der Fall beginnt. Du kannst nun mit einigen Personen sprechen und Hinweise sammeln.\n")

    available_npcs = list(characters)
    asked = 0
    while asked < 3 and available_npcs:
        choice = ask_choice("Wen möchtest du befragen? ", [npc['name'] for npc in available_npcs])
        talk_to_npc(available_npcs.pop(choice))
        asked += 1

    print("\nJetzt kannst du nach Hinweisen suchen.")
    for clue in clues:
        search_clue(clue)

    print("\nWas denkst du? Wer ist am wahrscheinlichsten verantwortlich?")
    suspect_choices = [npc['name'] for npc in characters]
    suspect = ask_choice("Wähle einen Verdächtigen: ", suspect_choices)

    print(f"\nDu hast dich entschieden: {suspect_choices[suspect]}.")
    print("\nHinweis: Diese Geschichte besteht aus mehreren Blickwinkeln. Deine Entscheidung ist eine Interpretation der verfügbaren Informationen.")
    print("Vielen Dank fürs Spielen!")


if __name__ == '__main__':
    main()
