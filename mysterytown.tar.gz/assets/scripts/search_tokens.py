import json, re
from pathlib import Path

p = Path('data') / 'extracted_story.json'
data = json.loads(p.read_text(encoding='utf-8'))
tokens = data.get('tokens', [])

patterns = [r'Code[:\s]*\d+', 'Stadtarchiv', 'Bootshaus', 'Schatzkammer', 'Schlüssel', 'Lavendel', 'Kästchen', 'Zettel', 'Hinweis', 'Notiz', 'Karte', 'Brunnen']

found = {}
for t in tokens:
    for pat in patterns:
        if re.search(pat, t, flags=re.IGNORECASE):
            found.setdefault(pat, []).append(t)

for k, v in found.items():
    print('---', k, '---')
    for x in list(dict.fromkeys(v))[:40]:
        print(x)
