import pygame

class DialogueBox:
    def __init__(self, width, height):
        self.rect = pygame.Rect(50, height - 150, width - 100, 120)
        self.bg_color = (30, 30, 30)
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont("Arial", 20)

    def draw(self, surface, name, text):
        # Hintergrund
        pygame.draw.rect(surface, self.bg_color, self.rect)
        pygame.draw.rect(surface, (200, 200, 200), self.rect, 2)

        # Name
        name_surf = self.font.render(f"{name}:", True, (255, 200, 0))
        surface.blit(name_surf, (self.rect.x + 10, self.rect.y + 10))

        # Text (einfacher Zeilenumbruch)
        words = text.split(' ')
        lines = []
        current_line = ""
        for word in words:
            test_line = current_line + word + " "
            if self.font.size(test_line)[0] < self.rect.width - 20:
                current_line = test_line
            else:
                lines.append(current_line)
                current_line = word + " "
        lines.append(current_line)

        for i, line in enumerate(lines):
            line_surf = self.font.render(line, True, self.text_color)
            surface.blit(line_surf, (self.rect.x + 10, self.rect.y + 40 + i * 25))
