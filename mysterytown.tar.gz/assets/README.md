# MysteryTown

A short narrative game prototype where the player visits a small town and investigates a mysterious event.

## Spielidee

Der Spieler kommt in eine kleine Stadt, in der etwas passiert ist, zum Beispiel:
- Ein wertvolles Objekt wurde gestohlen
- Ein Feuer ist ausgebrochen
- Eine Person ist verschwunden

Der Spieler spricht mit verschiedenen Figuren, findet Hinweise und muss aus begrenzten Informationen eine Deutung ableiten.

## Erste Inhalte

- `game.py`: kleines Textspiel
- `data/characters.json`: Figuren und ihre Aussagen
- `data/clues.json`: Hinweise und Ortshinweise
- `story/intro.txt`: Einleitender Text

## Start

Ausführen mit:

```bash
python game.py
```
