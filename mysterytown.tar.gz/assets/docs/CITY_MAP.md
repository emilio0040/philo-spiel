# Stadt-Skizze: MysteryTown

```text
#################################################################
#                          POLIZIST                             #
#      [ Haus Sabine ]                  [ Haus Ulrich ]         #
#          (1234)                           (5678)              #
#                                                               #
#   Ulrich (NW)        Thorsten (N)          Lotte (NO)         #
#                                                               #
#                      [ BOOTSHAUS ]                            #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~ FLUSS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
#                                                               #
#   Jonas (SW)         Sabine (S)            Anna (SO)          #
#                                                               #
#      [ Haus Lotte ]                   [ Haus Süd 2 ]          #
#          (2468)                           (1357)              #
#                                                               #
#################################################################
```

## Legende
- **#**: Stadtmauer / Grenze
- **[ ]**: Gebäude (Graue Blöcke mit grünen Eingängen)
- **( )**: Code für das Gebäude
- **~~~**: Fluss (Barriere)
- **NPCs**: Ulrich, Lotte, Jonas, Anna, Thorsten, Sabine, Polizist
