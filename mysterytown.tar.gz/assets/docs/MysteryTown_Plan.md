# MysteryTown - Projektplan & Stadt-Skizze

## 1. Setting & Atmosphäre
**Thema:** Mittelalterliches Dorf
**Besonderheit:** Ein Fluss teilt das Dorf in einen Nord- und einen Südteil. Der Zugang zum Süden ist zunächst gesperrt.

---

## 2. Stadt-Skizze (Layout)

```text
#################################################################
#                          POLIZIST                             #
#      [ Haus Sabine ]                  [ Haus Ulrich ]         #
#          (1234)                           (5678)              #
#                                                               #
#   Ulrich (NW)        Thorsten (N)          Lotte (NO)         #
#                                                               #
#                      [ BOOTSHAUS ]                            #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~ FLUSS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
#                                                               #
#   Jonas (SW)         Sabine (S)            Anna (SO)          #
#                                                               #
#      [ Haus Lotte ]                   [ Haus Süd 2 ]          #
#          (2468)                           (1357)              #
#                                                               #
#################################################################
```

**Legende:**
- **[ ]**: Gebäude (Graue Blöcke mit grünen Eingängen)
- **( )**: Code für das Gebäude
- **~~~**: Fluss (Barriere)
- **NPCs**: Ulrich, Lotte, Jonas, Anna, Thorsten, Sabine, Polizist

---

## 3. Gebäude & Orte
| Ort | Bereich | Code | Inhalt / Hinweis |
| :--- | :--- | :--- | :--- |
| Haus von Sabine (Bibliothek) | Nord | 1234 | Alte Münzen |
| Haus von Wache Ulrich | Nord | 5678 | Blaue Feder |
| Haus von Händlerin Lotte | Süd | 2468 | Lavendel-Fläschchen |
| Haus Süd 2 | Süd | 1357 | Goldener Knopf |
| Bootshaus | Mitte | Schlüssel | Zugang zum Südteil (Fähre) |

---

## 4. NPCs & Rollen
| Name | Rolle | Standort | Besonderheit |
| :--- | :--- | :--- | :--- |
| Wache Ulrich | Wache | Nord-West | Hat eine zerrissene Karte |
| Händlerin Lotte | Händlerin | Nord-Ost | Reagiert auf verschlammte Stiefel |
| Kind Jonas | Zeuge | Süd-West | Sah jemanden wegrennen |
| Bäckerin Anna | Zeugin | Süd-Ost | Fand Fußspuren im Mehl |
| Schmied Thorsten | Handwerker | Zentrum Nord | Vermisst seinen Hammer |
| Bibliothekarin Sabine | Gelehrte | Zentrum Süd | Fand eine blaue Feder |
| Polizist | Ermittler | Nördlicher Rand | Nimmt Verdacht erst nach 4 Häusern an |

---

## 5. Hinweise (Clues) & Story
- **Roter Mantel:** Auf dem Marktplatz gefunden.
- **Fußspuren:** Hinter der Bäckerei.
- **Verkaufte Ware:** Silbernes Kästchen bei Lotte.
- **Verschlammte Stiefel:** Hinter der Schmiede (Südteil).
- **Zerrissene Karte:** Im Norden gefunden.
- **Schlüssel:** Hinter dem Haus von Sabine (Nord-West).
- **Zettel mit Code:** Im Süden gefunden (Code: 1234).
- **Geheimes Notizbuch:** Von Lotte nach Konfrontation.

**Story-Mechanik:** Der Spieler muss durch das Sammeln von Gegenständen Lügen entlarven und so den wahren Täter finden.

---

## 6. Integrationsübersicht

- **Ziel:** PDF-gestützte Story-Elemente (Gegenstände, NPC-Änderungen, Ortsbeschreibungen) robust ins Spiel übernehmen.
- **Eingangsdaten:** `MysteryTown_Storyline_Wahrheitssiegel_Langfassung.pdf` (lokal im Projektverzeichnis).
- **Ausgabe:** Ergänzte/aktualisierte Dateien: `data/clues.json`, `data/characters.json`, `main.py` (welt- und objektpositionen).
- **Vorgehen:**
	- 1) Vollständige Seiten aus dem PDF dekodieren (ToUnicode CMaps, `TJ`-Arrays, Flusskomprimierung).
	- 2) Strukturierte Extraktion: für jedes gefundene Item/NPC/Ort eine standardisierte JSON-Repräsentation erzeugen.
	- 3) Validieren und testen: JSON-Schemas prüfen, `python -m py_compile` ausführen, Spielstart lokal testen.
	- 4) Inkrementelle Integration: erst `data/`-Dateien, danach `main.py`-Platzierungen und Dialoge.
- **Technische Hinweise:**
	- Keine externen PDF-Bibliotheken erforderlich — wir verwenden `zlib`, reguläre Ausdrücke und gezielte Byte-Parsing-Utilities.
	- Achten auf ToUnicode-CMaps, `TJ`-Spacing-Operatoren und komprimierte Streams.

---


