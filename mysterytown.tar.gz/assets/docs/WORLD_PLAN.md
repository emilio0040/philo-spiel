# Welt-Plan: MysteryTown (Arbeitstitel)

## Setting
Mittelalterliches Dorf mit einem Fluss, der die Stadt in einen Nord- und einen Südteil trennt.

## Gebäude & Orte (Oberwelt)
| Ort | Bereich | Code | Besonderheit |
| :--- | :--- | :--- | :--- |
| Stadtarchiv (Sabine) | Nord | 1234 | Enthält historische Dokumente |
| Haus von Wache Ulrich | Nord | 5678 | Ulrichs Privatunterkunft |
| Lottes Laden | Süd | 2468 | Handelszentrum |
| Bäckerei (Anna) | Süd | 1357 | Duftet nach frischem Brot |
| Schatzkammer | Zentrum | OFFEN | Der Tatort |
| Marktplatz | Zentrum Nord | - | Brunnen, Marktstände |
| Friedhof | Osten | - | Grabsteine, düstere Stimmung |
| Wohnhaus 1 | Nord-Ost | 1111 | Neues Haus |
| Wohnhaus 2 | Süd-West | 2222 | Neues Haus |
| Bootshaus | Mitte | Schlüssel | Zugang zum Südteil (Fähre) |

## Innenräume (Interiors)
Jedes Gebäude hat nun einen eigenen Innenraum im Pokémon-Stil:
- **Stadtarchiv:** Regale voller Bücher, Sabine arbeitet hier.
- **Lottes Laden:** Theke mit Waren, Lotte bedient Kunden.
- **Bäckerei:** Ofen, Mehlsäcke, Anna backt.
- **Schatzkammer:** Leeres Podest, zerbrochenes Glas.
- **Wohnhäuser:** Betten, Tische, persönliche Gegenstände.

## NPCs (Neue Verteilung)
| Name | Rolle | Standort |
| :--- | :--- | :--- |
| Wache Ulrich | Wache | Draußen (Patrouille Nord) |
| Händlerin Lotte | Händlerin | Innen (Lottes Laden) |
| Kind Jonas | Zeuge | Draußen (Marktplatz) |
| Bäckerin Anna | Zeugin | Innen (Bäckerei) |
| Schmied Thorsten | Handwerker | Draußen (Zentrum Nord) |
| Bibliothekarin Sabine | Gelehrte | Innen (Stadtarchiv) |
| Polizist | Ermittler | Draußen (Nördlicher Rand) |

## Hinweise (Clues)
- **Historische Dokumente:** Im Stadtarchiv.
- **Mehl-Fußspuren:** In der Bäckerei.
- **Leeres Podest:** In der Schatzkammer.
- **Verschlammte Stiefel:** Hinter der Schmiede (Draußen).
- **Zerrissene Karte:** Auf dem Friedhof (Neu!).
- **Schlüssel:** Auf dem Marktplatz versteckt (Neu!).
