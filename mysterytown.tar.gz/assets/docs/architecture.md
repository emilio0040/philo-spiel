# MysteryTown - Spielarchitektur

## 1. Übersicht
Ein 2D-Top-Down-Adventure im Nintendo-DS-Stil. Der Spieler bewegt sich durch eine Stadt, interagiert mit NPCs und sammelt Hinweise.

## 2. Komponenten
- **Game Engine:** Pygame
- **Grafik:** 
    - Spieler: Einfacher Block (vorerst).
    - NPCs: Farbige Blöcke.
    - Welt: Kachelbasiert (Tile-based) oder einfache statische Karte.
- **Eingabe:** WASD / Pfeiltasten zur Bewegung, 'E' oder 'Leertaste' zur Interaktion.
- **Zustandsverwaltung:**
    - `EXPLORING`: Frei bewegen.
    - `DIALOGUE`: Gespräch mit NPC.
    - `INVESTIGATING`: Hinweis untersuchen.
    - `DECISION`: Finale Auswahl des Täters.

## 3. Datenstruktur
- NPCs und Hinweise werden aus den vorhandenen JSON-Dateien geladen.
- NPCs erhalten zusätzlich eine Position (x, y) in der Welt.

## 4. Dateistruktur (Neu)
- `main.py`: Einstiegspunkt und Game-Loop.
- `engine.py`: Kernlogik (Rendering, Input, State).
- `entities.py`: Klassen für Player, NPC, Clue.
- `ui.py`: Dialogboxen und Menüs.
