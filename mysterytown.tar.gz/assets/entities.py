from matplotlib import colors
import pygame

def create_pixel_sprite(width, height, color_map, pixel_size=4):
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    for y, row in enumerate(color_map):
        for x, color in enumerate(row):
            if color:
                pygame.draw.rect(surface, color, (x * pixel_size, y * pixel_size, pixel_size, pixel_size))
    return surface

class Player:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 32, 32)
        self.speed = 5
        # Einfaches Pixel-Männchen
        colors = {
            'B': (50, 100, 255), # Blau (Körper)
            'H': (255, 220, 180), # Haut
            'S': (0, 0, 0),       # Schwarz (Augen/Schuhe)
            'H2': (100, 50, 0)    # Haare
        }
        p = None
        pixel_map = [
            [p, p, 'H2', 'H2', 'H2', 'H2', p, p],
            [p, 'H2', 'H2', 'H2', 'H2', 'H2', 'H2', p],
            [p, 'H', 'S', 'H', 'H', 'S', 'H', p],
            [p, 'H', 'H', 'H', 'H', 'H', 'H', p],
            [p, p, 'B', 'B', 'B', 'B', p, p],
            [p, 'B', 'B', 'B', 'B', 'B', 'B', p],
            [p, 'B', 'B', 'B', 'B', 'B', 'B', p],
            [p, 'S', 'S', p, p, 'S', 'S', p]
        ]
        color_map = [[colors[c] if c else None for c in row] for row in pixel_map]
        self.image = create_pixel_sprite(32, 32, color_map)

    def move(self, keys, walls):
        dx, dy = 0, 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: dx = -self.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx = self.speed
        if keys[pygame.K_UP] or keys[pygame.K_w]: dy = -self.speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]: dy = self.speed

        self.rect.x += dx
        for wall in walls:
            if self.rect.colliderect(wall):
                if dx > 0: self.rect.right = wall.left
                if dx < 0: self.rect.left = wall.right

        self.rect.y += dy
        for wall in walls:
            if self.rect.colliderect(wall):
                if dy > 0: self.rect.bottom = wall.top
                if dy < 0: self.rect.top = wall.bottom

    def draw(self, surface, camera):
        if camera:
            surface.blit(self.image, camera.apply(self))
        else:
            surface.blit(self.image, self.rect)

class NPC:
    def __init__(self, name, x, y, data):
        self.name = name
        self.rect = pygame.Rect(x, y, 32, 32)
        self.data = data
        self.color = (255, 100, 100) # Fallback
        
        # NPC Pixel-Art (ähnlich wie Player, aber andere Farben)
        npc_color = (200, 50, 50) if name != "Polizist" else (50, 50, 200)
        colors = {
            'C': npc_color,       # Kleidung
            'H': (255, 220, 180), # Haut
            'S': (0, 0, 0),       # Schwarz
            'H2': (80, 40, 0)     # Haare
        }
        p = None
        pixel_map = [
            [p, p, 'H2', 'H2', 'H2', 'H2', p, p],
            [p, 'H2', 'H2', 'H2', 'H2', 'H2', 'H2', p],
            [p, 'H', 'S', 'H', 'H', 'S', 'H', p],
            [p, 'H', 'H', 'H', 'H', 'H', 'H', p],
            [p, p, 'C', 'C', 'C', 'C', p, p],
            [p, 'C', 'C', 'C', 'C', 'C', 'C', p],
            [p, 'C', 'C', 'C', 'C', 'C', 'C', p],
            [p, 'S', 'S', p, p, 'S', 'S', p]
        ]
        color_map = [[colors[c] if c else None for c in row] for row in pixel_map]
        self.image = create_pixel_sprite(32, 32, color_map)

    def draw(self, surface, camera):
        if camera:
            surface.blit(self.image, camera.apply(self))
        else:
            surface.blit(self.image, self.rect)

class Clue:
    def __init__(self, title, x, y, data):
        self.title = title
        self.rect = pygame.Rect(x, y, 24, 24)
        self.data = data
        
        # Clue Pixel-Art (Schatztruhe/Beutel)
        colors = {
            'G': (255, 215, 0),  # Gold
            'B': (139, 69, 19),  # Braun
            'S': (0, 0, 0)       # Schwarz
        }
        p = None
        pixel_map = [
            [p, p, p, p, p, p],
            [p, 'B', 'B', 'B', 'B', p],
            [p, 'B', 'G', 'G', 'B', p],
            [p, 'B', 'B', 'B', 'B', p],
            [p, 'B', 'B', 'B', 'B', p],
            [p, p, p, p, p, p]
        ]
        color_map = [[colors[c] if c else None for c in row] for row in pixel_map]
        self.image = create_pixel_sprite(24, 24, color_map, pixel_size=4)

    def draw(self, surface, camera):
        if camera:
            surface.blit(self.image, camera.apply(self))
        else:
            surface.blit(self.image, self.rect)


class Tree:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 44, 36)

        # Farben
        colors = {
            'L': (34, 139, 34),   # Blätter
            'L2': (20, 110, 20),  # Dunklere Blätter
            'T': (139, 69, 19),   # Stamm
        }

        p = None

        # Pixel-Baum
        pixel_map = [
            [p,p,p,p,'L','L','L',p,p,p,p],
            [p,p,p,'L','L','L','L','L',p,p,p],
            [p,p,'L','L','L2','L','L2','L','L',p,p],
            [p,'L','L','L','L','L','L','L','L','L',p],
            [p,p,'L','L','L','L','L','L','L',p,p],
            [p,p,p,'L','L','L','L','L',p,p,p],
            [p,p,p,p,'T','T','T',p,p,p,p],
            [p,p,p,p,'T','T','T',p,p,p,p],
            [p,p,p,p,'T','T','T',p,p,p,p],
        ]

        color_map = [
            [colors[c] if c else None for c in row]
            for row in pixel_map
        ]

        self.image = create_pixel_sprite(
            44,   # Breite
            36,   # Höhe
            color_map,
            pixel_size=4
        )

    def draw(self, surface, camera):
        if camera:
            surface.blit(self.image, camera.apply(self))
        else:
            surface.blit(self.image, self.rect)
